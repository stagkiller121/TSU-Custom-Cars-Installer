# TSU Custom Cars

A plugin for **Turbo Sliders Unlimited** that brings custom 3D car models into the game. Turbo Sliders ships 18
car bodies; with this plugin a vehicle can use any `.glb` model on top of the stock physics, and custom cars are
shared through the normal **Steam Workshop**.

- **Workshop cars just work**: subscribe to a custom car and it appears in the game right away, with its model and
  paint, without restarting. Unsubscribe and it is gone again.
- **Everywhere in the game**: vehicle list, races, the vehicle editor's **Model** list, **CUSTOMIZE**, lap ghosts
  and saved ghost recordings.
- **Paintable**: the car's paint parts take your paint job from CUSTOMIZE (base colour, metallic, stripes,
  spheres, decals), like a stock body.
- **Fair**: physics, collisions and handling are always those of the stock body the car is built on, so a custom
  car races exactly like a stock vehicle with the same settings.
- **Works for everyone**: players without the plugin see the stock body (with the car's physics), so a shared
  vehicle is never broken.

**Who needs what**

| You want to... | You need |
|---|---|
| Drive custom cars from the Workshop | The installer, once. Then subscribe and play. [For players](#for-players) |
| Make your own custom cars | The installer, a `.glb` model, optionally Blender. [For car makers](#for-car-makers) |

---

## For players

### Requirements

- Turbo Sliders Unlimited on Steam (Windows). Tested with game build 25863877 (2026-11-20).
- The **.NET 8 Desktop Runtime** for the installer: https://dotnet.microsoft.com/download/dotnet/8.0

### Install

1. Close Turbo Sliders.
2. Download `TSU-CC-Release-<version>.zip` from the
   [Releases](../../releases) page and extract it.
3. Run `TSU Custom Cars Installer.exe`. It finds the game through Steam.
4. Click **Install / Repair**. It installs the mod loader (BepInEx 6.0.0-be.789, downloaded and checked for you),
   the plugin and its settings.
5. Start the game. **The first start takes about a minute longer** while BepInEx prepares itself; after that it
   starts normally.

That's it. You never need the installer's **Add car** button; that is for car makers.

### Update

- **From installer 0.5.2 on:** the installer checks GitHub for a newer version when it starts (nothing is sent but
  a request for the latest release; offline it simply says nothing). When one exists, the button next to
  Install / Repair reads **Update to x.y.z...**. Click it, read the release notes, click **Yes**: the installer
  downloads the new release into `%LOCALAPPDATA%\TSUCustomCarsInstaller\updates`, closes, replaces its own
  `.exe`, starts again and installs the new plugin. Your car packs, vehicles and settings are kept. Close the game
  first (the button refuses while TSU runs). **Check for updates** asks again at any time.
- **Installers 0.5.1 and older have no update button:** download `TSU-CC-Release-0.5.2.zip` once by hand from the
  [Releases](../../releases) page, run its installer and click **Install / Repair**. Later versions then update
  themselves.

**Install by hand instead:** extract BepInEx `BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.789+6cea286.zip` into the game
folder (the folder with `TSU.exe`), then extract `TSU-CC-TSUCustomCars-<version>-manual.zip` into the same folder.

### Play

1. Find a custom car on the Turbo Sliders Steam Workshop and click **Subscribe**.
2. In the game it shows up within a few seconds (no restart): PLAY > VEHICLES.
3. Race, paint it in CUSTOMIZE, race AI, record ghosts - like any other vehicle.
4. **Unsubscribe** on the Workshop and the car leaves the game within a few seconds. Steam deletes the download
   when you close the game.

### Online

Custom models are drawn only in local games and on servers you host as Private or Hidden. On public servers,
and when joining other people's servers, everyone sees stock bodies (joining a friend's server can be allowed
with `AllowClientOnAllowlistedHosts` and `ClientAllowlist` in the config). Unfinalized vehicles cannot be used
online at all - that is the game's own rule.

### Uninstall

- Installer: **Uninstall...** removes the plugin, its settings, every car pack and the plugin's Model-list
  choices; BepInEx only if the installer installed it (it asks). It also finds vehicle files that carry a custom
  model (your own vehicles and Workshop downloads) and offers to remove just those models: the vehicles stay and
  go back to their stock body. Nothing else in your saves is touched.
- **Taking the custom vehicles out of the vehicle list** (since 0.5.1): Uninstall also lists your own vehicles that
  carry (or carried) a custom model and asks *"Also remove these vehicles from the vehicle list?"*. Your vehicles
  folder is synced by **Steam Cloud**, and Steam puts back files that were deleted while the game was closed, so the
  deletion is one more step:
  1. Start Turbo Sliders (it runs normally without the plugin).
  2. In the installer click **Remove leftover custom vehicles...** (shown after such an uninstall, usable only while
     the game runs). It backs up every file to `%LOCALAPPDATA%\TSUCustomCarsInstaller\backups\<date-time>\`, then
     deletes the vehicles and the game's `.veh.bak` copies of them. Vehicles without a custom model are never touched.
  3. Quit the game with **EXIT** in its main menu so Steam Cloud saves the deletion. The running game still lists
     the vehicles until its next start.
- **Workshop subscriptions** cannot be removed by the installer (only Steam can do that). Uninstall lists the
  downloaded Workshop vehicles with a custom model and offers to open their Workshop pages in Steam, so you can click
  **Unsubscribe** on each. Steam deletes the downloads when the game is closed.
- By hand: delete `BepInEx\plugins\TSUCustomCars\` and `BepInEx\config\com.stagk.tsucustomcars.cfg`. To remove
  BepInEx too: `winhttp.dll`, `doorstop_config.ini`, `.doorstop_version`, `changelog.txt`, `dotnet\` and
  `BepInEx\` in the game folder.
- Quick off switch: in `BepInEx\config\com.stagk.tsucustomcars.cfg` set `Enabled = false`.

No original game file is changed.

### Troubleshooting

- Log file: `<game>\BepInEx\LogOutput.log` (lines from `TSUCustomCars`).
- A Workshop car shows a stock body: check that the plugin is installed (the log has `TSUCustomCars ... loaded`)
  and `Enabled = true` in the config. The car's author must have shared it with the plugin installed, otherwise
  the upload carries no model.
- **Authors: your own copy hides your Workshop download.** A vehicle you published keeps the same vehicle id in your
  `Vehicles` folder as on the Workshop, and the game lists only one vehicle per id - your own copy. If your copy has
  no model (for example after an uninstall removed it), the plugin uses the model of the subscribed download
  instead (since 0.5.1; the log says `using the model from Workshop item <id> for your own copy '<name>'`). Your
  file is not changed. To get rid of the own copies, use **Remove leftover custom vehicles** (see Uninstall).
- After a game update BepInEx rebuilds its files on the first start (one slow start). If the game code changed a
  lot, a plugin update may be needed - check the Releases page.

---

## For car makers

How it works in short: you turn a `.glb` model into a **car pack** with the installer, build a vehicle on it in
the game's vehicle editor, and share that vehicle on the Workshop. **The plugin puts the model inside the shared
vehicle file**, so subscribers get it automatically; they never need your pack.

### What a model needs

- **glTF binary (`.glb`)**, Y up, the car facing forward along +Z (the glTF default).
- **Wheels the plugin can spin**: four nodes `wheel_FL`, `wheel_FR`, `wheel_RL`, `wheel_RR`. A raw model without
  them is usually fine too: **Add car** finds the wheels by their shape (see
  [Automatic wheel detection](#automatic-wheel-detection)). The prep script below splits them by material instead.
- A sensible size: around **30k triangles** works well; the prep script decimates bigger models.
- **Only use models you are allowed to share**, and keep their credits (`CREDITS.txt`) with the pack.

### 1. Prepare the model (Blender 4+/5)

Sketchfab and similar models usually need this (merged wheels, interiors, 200k+ triangles):

```
blender -b -P tools/prep_car_glb.py -- <in.glb> <out folder> <name> <prep.json>
```

`prep.json` lists which materials to delete (e.g. the interior) and which are wheels, glass and paint - see
`tools/cars/clk_gtr.prep.json` for an example. The script splits the wheels into `wheel_FL/FR/RL/RR`, decimates to
about 28k triangles, turns the car the right way round, writes preview images, and unwraps the **paint**
materials into a clean UV layout (paint jobs need UVs inside 0..1 that do not overlap).

### 2. Make the car pack

In the installer: **Add car...** > pick the `.glb` > enter a **Name**, Body **Auto** (picks the stock body whose
wheelbase is closest), Mode **add**. The pack goes to `<game>\BepInEx\plugins\TSUCustomCars\cars\<name>\` and adds
a new vehicle with that name to the game.

You can also write the pack's `.json` by hand like `tools/cars/clk_gtr.json`; packs can be shared as a zip with
the `.json`, the `.glb` and `CREDITS.txt`, and added with **Add car...**.

### Automatic wheel detection

Since 0.5.0, **Add car** with a raw `.glb` (for example straight from Sketchfab) looks for the model's own wheels, so
they spin and steer in the game instead of the stock wheels.

What it does:

- Splits the model into pieces (also inside merged meshes) and looks for pieces that are **round seen from the side**,
  stand on **one ground line** at the four corners and come in **left/right pairs**. Tyre, rim, brake disc, hub cap,
  bolts and tread blocks of one wheel are grouped by their shared axle; parts that are not round and not repeated
  around the axle (brake calipers, suspension arms, mudguards) stay on the body. Since 0.5.2 everything lying inside
  the wheel that reaches the tyre (tread and sidewall pieces of a tyre cut up by the exporter, white walls), round
  parts around the axle (hub caps, drums), fragments of the wheel's faces and spokes of slightly different sizes go
  with the wheel too, and the wheel's pivot is the hub centre fitted through its round parts. An installer log line
  says how much was taken in (`... triangles inside the wheel (tyre pieces, hub parts) taken with it`).
- Ignores **spare wheels** (not on the ground), the **steering wheel**, round lamps and exhausts.
- Trucks with more than two axles: the front axle steers, the rearmost axle is the rear axle, wheels on the middle
  axles become **extra wheels** that spin with the car (`wheels.extra` in the manifest).
- Works out which way is up and forward (Y-up or Z-up models, turned or slightly tilted models). Front and rear come
  from part names (head/tail lights, front/rear, wheel names such as `wheelFL`, also on parent parts); without such
  names from **red tail-light lenses** at one end and **smaller front wheels** (2.5 % or more); without those the model is taken to
  face +Z (glTF's convention; -Y for Z-up models). The result box says which it was, for example
  `front: front/rear from part names` or `front: no front/rear hints in the part names: assumed the model faces +Z`.
- Writes a **copy** of the model into the pack in which every wheel is its own node (`wheel_FL` ... with its pivot
  at the wheel centre). Your original file is never changed. Nothing else in the model is dropped.
- Also applies safe fixes to raw models without TSU tags: textures with a black colour factor are shown (white
  factor), see-through cut-outs (`BLEND` with a texture) become `MASK` instead of glass, glass-like materials are
  tagged as glass, and a plain-coloured paint material (`carpaint`, `body`, ...) is tagged as paint. A paint material
  with its own texture (a livery) is left alone.
- A model that already has `wheel_FL`...`wheel_RR` is used exactly as before.

The Add car dialog (since 0.5.2):

- **Wheels:** *Find them automatically* (the detection above), *Pick the four wheel parts myself*, *Use the game's
  stock wheels*, or *Use the model as it is (no changes at all)* (the old unticked box).
- **Pick the four wheel parts myself:** when the detection finds no wheels or the wrong ones. Four lists (front
  left, front right, rear left, rear right) show the model's parts, wheel-like names first, with their triangle
  counts. Pick the part that holds the whole wheel (tyre and rim); everything under it goes with the wheel. Left and
  right are checked from the positions (a mix-up is corrected and noted), the pair you pick as front is the front
  (unless **Front** says otherwise). A part longer than about half the car, or the same part twice, is refused and
  the car keeps the stock wheels.
- **Front:** *Auto* (as described above), *As modelled* (the file's own front: +Z, -Y for Z-up models) or *Turned
  around* (the other end). Use *Turned around* when a car drives backwards. The wheels follow, so the front pair
  still steers. Stored as `"transform": { "front": "turned" }` in the pack's `.json`; when the model itself is not
  rewritten (wheels by name, stock wheels, prepared models) the pack turns it with `"rotationEuler": [0, 180, 0]`
  and swapped wheel corners instead. Packs with `"wheels": { "mode": "auto" }` honour `front` when the plugin finds
  the wheels; a vehicle shared on the Workshop carries the result.

After **Add car** the installer shows (and logs) the result, for example:

```
Found 4 wheels (high): front r=0.51 m, rear r=0.51 m, 2 spare wheels ignored
- glass: 'glasses_glass__0'
- paint: 'Material.001' looks like the paint but has its own texture (a livery?) - kept as it is
```

- `high` / `medium`: the wheels are used. `low` / no wheels: the car keeps the game's own wheels and the line says
  why (for example *wheels fused into the body*: one-piece scans whose wheels are not separate geometry).
- `paint guessed: '<material>'`: that material takes your paint job from CUSTOMIZE. Wrong guess? Put the right one
  into `materials.paint` (or `materials.keep`) in the pack's `.json`. An untextured black `carpaint` next to a
  coloured one (a race car's black chassis) is not taken.
- `front: ...`: how the front was decided (names, lamps / wheel sizes, assumed, or set by hand).

**Packs copied by hand**: if a pack's `.json` says `"wheels": { "mode": "auto" }`, or names wheel nodes that a raw
model does not have, the plugin runs the same detection when the game starts (in memory; the file is not changed) and
writes the result to `BepInEx\LogOutput.log`:

```
[Info   :TSUCustomCars] [mytruck] mytruck.json: no wheel nodes in the model, automatic wheel detection: Found 4 wheels (high): ... (412 ms)
```

A vehicle shared on the Workshop then carries the fixed model, so other players get the same wheels.

Limits: wheels that are fused into the body (one-mesh 3D scans) cannot be separated - those cars keep the stock
wheels (or pick nothing: there are no wheel parts to pick). Front and rear come from names, red lamps, wheel sizes or
the +Z convention; when all of them are wrong, use **Front: Turned around**. Extra wheels spin, they do not steer.

### Paint jobs on custom bodies (paint layout)

The game paints a car (stripes, spheres, decals, brush strokes) into one 2048 x 2048 paint texture through the paint
parts' UVs: a spot on the texture shows wherever the model's UVs point to it. Most downloaded models re-use and mirror
their UV islands (the 1994 Lancia Delta: 77 % of the painted area is shared by 2 to 31 places on the body; the 2022
Apollo Project EVO shares every left panel with the right one), so one decal shows up as fragments all over the car,
or a stripe on one side appears on the other side too. Hand-prepared packs with several paint parts overlap too (each part was
unwrapped on its own).

Since 0.5.2 the plugin gives the paint parts a clean layout when the game loads the car: one box-projected atlas
over all paint parts of the car (the parts' own textures are never shown on paint parts, so nothing visible is lost);
surfaces that fold over themselves get pieces of their own. Layouts that are already clean are kept. It is **on by
default**; to turn it off, set in `BepInEx\config\com.stagk.tsucustomcars.cfg`:

```
[Paint]
RepairPaintLayout = false
```

(0.5.2 test builds called the setting `RepairPaintUv`; that old line is no longer read and is removed from the file.)

`BepInEx\LogOutput.log` then shows a line per car, for example
`paint: paint layout rebuilt (77% of the paint texels overlap): 42686 paint triangles in 1 part(s) -> 2210 charts, 22% of the texture used, overlap 77% -> 0.0%`.
The layout only changes where the strokes are stored in the texture; the game places them by the car's 3D shape, so
nothing has to match between players. Limits: the layout uses about a fifth of the texture (fine for
decals, a little softer than stock cars); sharp seams between charts can show a thin line on a stripe.

The number of paint operations (`x / 26 paint operations used`) is the game's own limit per paint job and is the same
for custom cars. Note that a custom car shares the paint job of its **base body** (the Body chosen in Add car): all
custom cars on Super1 and the stock Super1 use the same paint job and the same 26 operations. Give cars you want to
paint differently different bodies.

### Plain white body (paintable)

The Add car dialog has a second box, **Plain white body (paintable) - removes the model's own body colour so players
can paint it**. It is **off** by default: the car keeps its own colour or livery. When it is on, the car gets the
plain white paintable body of the hand-converted cars:

- The **paint material(s)** of the body get a white colour factor and lose their own colour texture (the livery),
  and are tagged as paint, so CUSTOMIZE paint jobs show in full. Alpha, normal/roughness maps and everything else
  of that material stay.
- **Glass, lights, tyres, rims, interior, chrome, badges, grilles, carbon** and all other materials are not changed.
- Which material is the paint: a material already tagged or listed as paint; else the same guess as above, but a
  livery body is now taken too (`carpaint` with a texture, Forza-style `..._mm_ext1` shells, `...Base1` paint), plus
  small extra parts whose own name says paint (e.g. `paint_mirrors`; not satin/grey trim).
- If no material is clearly the paint, nothing is whitened and the result box says **NOT applied** with the reason,
  for example a one-material 3D scan or texture atlas (one textured material covering the whole car, also used by
  the wheels, or a model without any glass material). Then list the body material by hand in `materials.paint`.
- A textured cut-out paint material (`MASK`) keeps its texture (its holes would close without it).
- Works with the wheel detection off too (only the paint changes), and on models that already have `wheel_FL`... .

The choice is stored in the pack's `.json` (only when the body really is plain white now):

```json
"materials": { "plainWhite": true }
```

The plugin honours the key for packs copied by hand and for embedded (Workshop) vehicles: if the model's paint is not
plain white yet (a raw `.glb`), it is made white in memory when the game starts (the file is not changed; the log says
`plain white body: '<material>' made plain white and paintable` or why not), and a vehicle shared on the Workshop
carries the white model. You can also add the key to any pack by hand; together with `materials.paint` it whitens
exactly the listed materials. Zip/folder packs added with **Add car** are taken as their author made them.

Limits: the material is whitened as a whole - details painted into the livery texture (panel lines, vents printed on
the body) go with it. Decal layers drawn as separate meshes over the paint (some racing liveries) stay. For stripes
and decals on raw models see *Paint jobs on custom bodies* above (a solid colour is always fine).

### 3. Tune it

Edit the pack's `.json` and respawn the car (restart button in the vehicle editor) - changes show without
restarting the game. Useful keys:

| Key | What it does |
|---|---|
| `wheels.inset` | Push wheels into the body (metres, + = inward), per `front`/`rear` or `FL/FR/RL/RR` |
| `wheels.mode` | `custom` (nodes below), `stock` (the game's wheels) or `auto` (the plugin finds them when the game starts) |
| `wheels.extra` | Spin-only wheels on middle axles: `[{"node": "wheel_A2L", "side": "L", "axle": 2}]` |
| `wheels.modelTrack` | Put the wheels at the model's own track width |
| `transform.offset` / `transform.scale` / `transform.fitToWheelbase` | Position and size of the body |
| `vehicle.name`, `vehicle.description` | What the vehicle list shows (description 4-128 characters) |
| `materials.paint` | Materials that take the player's paint job, e.g. `["body"]` |

### 4. Build your vehicle in the game

1. CREATE > VEHICLE EDITOR > the car icon (top right) > **Model** > pick your custom model (it is listed after
   Hypercar; also in the CUSTOMIZE model stepper).
2. Tune the physics as usual, paint it in CUSTOMIZE, save, and **finalize** it.
3. **AI opponents** need AI lines for that exact vehicle on each track: CREATE > AI EDITOR (only finalized vehicles
   are listed). Hotlapping does not record AI lines.

### 5. Share it on the Workshop

Share the finalized vehicle from the vehicle editor as usual. The plugin adds the model to the upload; the log
shows `embedded model '<id>' (... KB) into <vehicle>.veh ... (Workshop share)`. Expect the Workshop item to be a
few MB (the model) instead of a few hundred bytes. Put the model's credits and licence in the Workshop
description.

**Testing your upload:** on your own PC your local copy of the vehicle always wins over the Workshop download
(it is the same vehicle), so a subscriber's view is best checked from a second PC or Steam account with only the
plugin installed.

---

## Building from source

- Plugin: `dotnet build src/TSUCustomCars -c Release -p:UseInterop=true` (needs BepInEx installed in the game,
  path via `-p:TSUGameDir=...`).
- BepInEx interop files without starting the game:
  `dotnet run -c Release --project tools/OfflineInterop -- "<game dir>"`.
- Tests: `dotnet run -c Release --project tests/TSUCustomCars.Tests` (offline, against stub data; close the game
  first).
- Installer: `dotnet publish src/TSUCustomCars.Installer -c Release -o out` (it bundles the plugin from
  `src/TSUCustomCars/bin/Release`).
- Release zip: `python -I tools/make_release.py <version> <plugin dll> <installer exe> <out dir>`.

## Credits

- [BepInEx](https://github.com/BepInEx/BepInEx), [Il2CppInterop](https://github.com/BepInEx/Il2CppInterop),
  [Harmony](https://github.com/pardeike/Harmony), Cpp2IL - the modding framework.
- Turbo Sliders Unlimited belongs to its developers. This is an unofficial fan mod, not affiliated with or
  endorsed by them.
- Example car (CLK GTR pack): model "Mercedes-Benz CLK GTR" by Dave Bored, CC-BY-4.0 (see the pack's
  `CREDITS.txt`). Mercedes-Benz and CLK GTR are trademarks of Mercedes-Benz Group AG; not affiliated or endorsed.
- **AI disclosure**: the plugin, installer and tools were written with Claude (Anthropic, Claude Code, model
  Claude Opus 5.5), directed and play-tested by the author.

## License

The code in this repository is MIT licensed (see `LICENSE`). Car models keep their own licences (see each pack's
`CREDITS.txt`).
